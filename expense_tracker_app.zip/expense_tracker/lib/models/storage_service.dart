import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/expense.dart';

class StorageService {
  static const _expenseKey = 'expenses';
  static const _budgetKey = 'budgets';

  static Future<List<Expense>> getExpenses() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_expenseKey) ?? [];
    return data.map((e) => Expense.fromJson(e)).toList();
  }

  static Future<void> saveExpense(Expense expense) async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_expenseKey) ?? [];
    data.add(expense.toJson());
    await prefs.setStringList(_expenseKey, data);
  }

  static Future<void> deleteExpense(String id) async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getStringList(_expenseKey) ?? [];
    data.removeWhere((e) {
      final map = jsonDecode(e);
      return map['id'] == id;
    });
    await prefs.setStringList(_expenseKey, data);
  }

  static Future<Map<String, double>> getBudgets() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_budgetKey);
    if (raw == null) return {};
    final Map<String, dynamic> decoded = jsonDecode(raw);
    return decoded.map((k, v) => MapEntry(k, (v as num).toDouble()));
  }

  static Future<void> saveBudget(String categoryIndex, double amount) async {
    final prefs = await SharedPreferences.getInstance();
    final budgets = await getBudgets();
    budgets[categoryIndex] = amount;
    await prefs.setString(_budgetKey, jsonEncode(budgets));
  }
}
