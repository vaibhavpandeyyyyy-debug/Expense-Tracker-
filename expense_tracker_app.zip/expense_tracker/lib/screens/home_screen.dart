import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/expense.dart';
import '../models/storage_service.dart';
import 'add_expense_screen.dart';
import 'summary_screen.dart';
import 'budget_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Expense> _expenses = [];
  int _selectedMonth = DateTime.now().month;
  int _selectedYear = DateTime.now().year;
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _loadExpenses();
  }

  Future<void> _loadExpenses() async {
    final expenses = await StorageService.getExpenses();
    setState(() => _expenses = expenses);
  }

  List<Expense> get _filteredExpenses => _expenses.where((e) =>
    e.date.month == _selectedMonth && e.date.year == _selectedYear).toList()
    ..sort((a, b) => b.date.compareTo(a.date));

  double get _totalThisMonth =>
    _filteredExpenses.fold(0, (sum, e) => sum + e.amount);

  @override
  Widget build(BuildContext context) {
    final screens = [
      _buildHomeContent(),
      SummaryScreen(expenses: _expenses),
      BudgetScreen(expenses: _expenses, onChanged: _loadExpenses),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF0D0D1A),
      body: screens[_currentIndex],
      bottomNavigationBar: _buildBottomNav(),
      floatingActionButton: _currentIndex == 0 ? FloatingActionButton(
        onPressed: () async {
          await Navigator.push(context,
            MaterialPageRoute(builder: (_) => const AddExpenseScreen()));
          _loadExpenses();
        },
        backgroundColor: const Color(0xFF7C3AED),
        child: const Icon(Icons.add, color: Colors.white),
      ) : null,
    );
  }

  Widget _buildHomeContent() {
    return SafeArea(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          _buildMonthSelector(),
          _buildTotalCard(),
          _buildExpenseList(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Row(
        children: [
          Text('Expenses', style: GoogleFonts.spaceMono(
            color: Colors.white,
            fontSize: 28,
            fontWeight: FontWeight.bold,
          )),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.wallet, color: Color(0xFF7C3AED), size: 24),
          ),
        ],
      ),
    );
  }

  Widget _buildMonthSelector() {
    final months = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'];
    return SizedBox(
      height: 50,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        itemCount: 12,
        itemBuilder: (ctx, i) {
          final isSelected = i + 1 == _selectedMonth;
          return GestureDetector(
            onTap: () => setState(() => _selectedMonth = i + 1),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              decoration: BoxDecoration(
                color: isSelected ? const Color(0xFF7C3AED) : const Color(0xFF1A1A2E),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Text(months[i], style: TextStyle(
                color: isSelected ? Colors.white : Colors.grey,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                fontSize: 13,
              )),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTotalCard() {
    return Container(
      margin: const EdgeInsets.all(16),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFF4C1D95)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7C3AED).withOpacity(0.4),
            blurRadius: 20,
            offset: const Offset(0, 8),
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Total Spent', style: GoogleFonts.spaceMono(
            color: Colors.white70, fontSize: 14)),
          const SizedBox(height: 8),
          Text('₹${NumberFormat('#,##,###.##').format(_totalThisMonth)}',
            style: GoogleFonts.spaceMono(
              color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          Text(
            '${_filteredExpenses.length} transactions this month',
            style: const TextStyle(color: Colors.white60, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildExpenseList() {
    if (_filteredExpenses.isEmpty) {
      return Expanded(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text('💸', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 12),
              Text('No expenses this month',
                style: TextStyle(color: Colors.grey[500], fontSize: 16)),
              const SizedBox(height: 4),
              Text('Tap + to add one',
                style: TextStyle(color: Colors.grey[700], fontSize: 13)),
            ],
          ),
        ),
      );
    }

    return Expanded(
      child: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _filteredExpenses.length,
        itemBuilder: (ctx, i) => _buildExpenseTile(_filteredExpenses[i]),
      ),
    );
  }

  Widget _buildExpenseTile(Expense expense) {
    return Dismissible(
      key: Key(expense.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 20),
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: Colors.red.shade900,
          borderRadius: BorderRadius.circular(16),
        ),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      onDismissed: (_) async {
        await StorageService.deleteExpense(expense.id);
        _loadExpenses();
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: Color(expense.category.colorValue).withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(expense.category.emoji,
                  style: const TextStyle(fontSize: 20)),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(expense.title,
                    style: const TextStyle(color: Colors.white,
                      fontWeight: FontWeight.w600, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(
                    '${expense.category.label} · ${DateFormat('dd MMM').format(expense.date)}',
                    style: TextStyle(color: Colors.grey[500], fontSize: 12),
                  ),
                ],
              ),
            ),
            Text(
              '₹${NumberFormat('#,##,###.##').format(expense.amount)}',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      onTap: (i) => setState(() => _currentIndex = i),
      backgroundColor: const Color(0xFF1A1A2E),
      selectedItemColor: const Color(0xFF7C3AED),
      unselectedItemColor: Colors.grey,
      type: BottomNavigationBarType.fixed,
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'Summary'),
        BottomNavigationBarItem(icon: Icon(Icons.account_balance_wallet), label: 'Budget'),
      ],
    );
  }
}
