import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/expense.dart';

class SummaryScreen extends StatefulWidget {
  final List<Expense> expenses;
  const SummaryScreen({super.key, required this.expenses});
  @override
  State<SummaryScreen> createState() => _SummaryScreenState();
}

class _SummaryScreenState extends State<SummaryScreen> {
  int _selectedMonth = DateTime.now().month;
  int _selectedYear = DateTime.now().year;

  List<Expense> get _filtered => widget.expenses.where((e) =>
    e.date.month == _selectedMonth && e.date.year == _selectedYear).toList();

  Map<Category, double> get _byCategory {
    final map = <Category, double>{};
    for (final e in _filtered) {
      map[e.category] = (map[e.category] ?? 0) + e.amount;
    }
    return map;
  }

  double get _total => _filtered.fold(0, (s, e) => s + e.amount);

  @override
  Widget build(BuildContext context) {
    final byCategory = _byCategory;
    final sorted = byCategory.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Summary', style: GoogleFonts.spaceMono(
              color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            _buildMonthPicker(),
            const SizedBox(height: 20),
            if (_filtered.isEmpty)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 60),
                  child: Text('No data for this month 📊',
                    style: TextStyle(color: Colors.grey)),
                ),
              )
            else ...[
              _buildPieChart(byCategory),
              const SizedBox(height: 24),
              _buildCategoryBars(sorted),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildMonthPicker() {
    final months = ['Jan','Feb','Mar','Apr','May','Jun',
                    'Jul','Aug','Sep','Oct','Nov','Dec'];
    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.chevron_left, color: Colors.white),
          onPressed: () => setState(() {
            if (_selectedMonth == 1) { _selectedMonth = 12; _selectedYear--; }
            else _selectedMonth--;
          }),
        ),
        Expanded(
          child: Center(
            child: Text(
              '${months[_selectedMonth - 1]} $_selectedYear',
              style: const TextStyle(color: Colors.white,
                fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        IconButton(
          icon: const Icon(Icons.chevron_right, color: Colors.white),
          onPressed: () => setState(() {
            if (_selectedMonth == 12) { _selectedMonth = 1; _selectedYear++; }
            else _selectedMonth++;
          }),
        ),
      ],
    );
  }

  Widget _buildPieChart(Map<Category, double> byCategory) {
    final sections = byCategory.entries.map((entry) {
      final pct = _total > 0 ? entry.value / _total * 100 : 0;
      return PieChartSectionData(
        value: entry.value,
        color: Color(entry.key.colorValue),
        title: '${pct.toStringAsFixed(0)}%',
        radius: 60,
        titleStyle: const TextStyle(color: Colors.white,
          fontSize: 12, fontWeight: FontWeight.bold),
      );
    }).toList();

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A2E),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Text('Total: ₹${NumberFormat('#,##,###.##').format(_total)}',
            style: GoogleFonts.spaceMono(
              color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          SizedBox(
            height: 200,
            child: PieChart(PieChartData(
              sections: sections,
              centerSpaceRadius: 40,
              sectionsSpace: 2,
            )),
          ),
        ],
      ),
    );
  }

  Widget _buildCategoryBars(List<MapEntry<Category, double>> sorted) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('By Category', style: GoogleFonts.spaceMono(
          color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...sorted.map((entry) {
          final pct = _total > 0 ? entry.value / _total : 0.0;
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A2E),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(entry.key.emoji, style: const TextStyle(fontSize: 20)),
                    const SizedBox(width: 10),
                    Text(entry.key.label,
                      style: const TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w600)),
                    const Spacer(),
                    Text('₹${NumberFormat('#,##,###.##').format(entry.value)}',
                      style: const TextStyle(color: Colors.white,
                        fontWeight: FontWeight.bold)),
                  ],
                ),
                const SizedBox(height: 10),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: pct.toDouble(),
                    backgroundColor: Colors.grey[800],
                    valueColor: AlwaysStoppedAnimation(Color(entry.key.colorValue)),
                    minHeight: 6,
                  ),
                ),
              ],
            ),
          );
        }),
      ],
    );
  }
}
