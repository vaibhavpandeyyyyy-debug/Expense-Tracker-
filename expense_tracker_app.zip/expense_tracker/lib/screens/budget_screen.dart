import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import '../models/expense.dart';
import '../models/storage_service.dart';

class BudgetScreen extends StatefulWidget {
  final List<Expense> expenses;
  final VoidCallback onChanged;
  const BudgetScreen({super.key, required this.expenses, required this.onChanged});
  @override
  State<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends State<BudgetScreen> {
  Map<String, double> _budgets = {};

  @override
  void initState() {
    super.initState();
    _loadBudgets();
  }

  Future<void> _loadBudgets() async {
    final b = await StorageService.getBudgets();
    setState(() => _budgets = b);
  }

  double _spentThisMonth(Category cat) {
    final now = DateTime.now();
    return widget.expenses
      .where((e) => e.category == cat &&
        e.date.month == now.month && e.date.year == now.year)
      .fold(0, (s, e) => s + e.amount);
  }

  void _editBudget(Category cat) {
    final ctrl = TextEditingController(
      text: _budgets[cat.index.toString()]?.toStringAsFixed(0) ?? '');
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF1A1A2E),
        title: Text('${cat.emoji} ${cat.label} Budget',
          style: const TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl,
          keyboardType: TextInputType.number,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Enter monthly budget (₹)',
            hintStyle: TextStyle(color: Colors.grey[600]),
            filled: true,
            fillColor: const Color(0xFF0D0D1A),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF7C3AED)),
            onPressed: () async {
              final val = double.tryParse(ctrl.text);
              if (val != null && val > 0) {
                await StorageService.saveBudget(cat.index.toString(), val);
                await _loadBudgets();
              }
              if (mounted) Navigator.pop(context);
            },
            child: const Text('Save', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Budget', style: GoogleFonts.spaceMono(
              color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text('This month\'s limits',
              style: TextStyle(color: Colors.grey[500], fontSize: 14)),
            const SizedBox(height: 20),
            ...Category.values.map((cat) => _buildBudgetCard(cat)),
          ],
        ),
      ),
    );
  }

  Widget _buildBudgetCard(Category cat) {
    final spent = _spentThisMonth(cat);
    final budget = _budgets[cat.index.toString()];
    final hasLimit = budget != null && budget > 0;
    final progress = hasLimit ? (spent / budget!).clamp(0.0, 1.0) : 0.0;
    final isOver = hasLimit && spent > budget!;

    return GestureDetector(
      onTap: () => _editBudget(cat),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: const Color(0xFF1A1A2E),
          borderRadius: BorderRadius.circular(16),
          border: isOver
            ? Border.all(color: Colors.red.shade700, width: 1)
            : null,
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Color(cat.colorValue).withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(cat.emoji, style: const TextStyle(fontSize: 18)),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(cat.label,
                        style: const TextStyle(color: Colors.white,
                          fontWeight: FontWeight.w600, fontSize: 15)),
                      Text(
                        hasLimit
                          ? 'Spent ₹${NumberFormat('#,##,###').format(spent)} of ₹${NumberFormat('#,##,###').format(budget)}'
                          : 'Spent ₹${NumberFormat('#,##,###').format(spent)} · Tap to set limit',
                        style: TextStyle(color: Colors.grey[500], fontSize: 12),
                      ),
                    ],
                  ),
                ),
                if (isOver)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.red.shade900,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text('Over!',
                      style: TextStyle(color: Colors.white, fontSize: 11,
                        fontWeight: FontWeight.bold)),
                  )
                else
                  const Icon(Icons.edit, color: Colors.grey, size: 16),
              ],
            ),
            if (hasLimit) ...[
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey[800],
                  valueColor: AlwaysStoppedAnimation(
                    isOver ? Colors.red : Color(cat.colorValue)),
                  minHeight: 6,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
