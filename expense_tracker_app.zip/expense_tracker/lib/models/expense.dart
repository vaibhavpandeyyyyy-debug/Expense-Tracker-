import 'dart:convert';

enum Category {
  food,
  rent,
  transport,
  shopping,
  health,
  entertainment,
  education,
  other,
}

extension CategoryExtension on Category {
  String get label {
    switch (this) {
      case Category.food: return 'Food';
      case Category.rent: return 'Rent';
      case Category.transport: return 'Transport';
      case Category.shopping: return 'Shopping';
      case Category.health: return 'Health';
      case Category.entertainment: return 'Entertainment';
      case Category.education: return 'Education';
      case Category.other: return 'Other';
    }
  }

  String get emoji {
    switch (this) {
      case Category.food: return '🍔';
      case Category.rent: return '🏠';
      case Category.transport: return '🚗';
      case Category.shopping: return '🛒';
      case Category.health: return '💊';
      case Category.entertainment: return '🎬';
      case Category.education: return '📚';
      case Category.other: return '📦';
    }
  }

  int get colorValue {
    switch (this) {
      case Category.food: return 0xFFFF6B6B;
      case Category.rent: return 0xFF845EC2;
      case Category.transport: return 0xFF4D8AF0;
      case Category.shopping: return 0xFFFF9671;
      case Category.health: return 0xFF00C9A7;
      case Category.entertainment: return 0xFFFFD93D;
      case Category.education: return 0xFF6BCB77;
      case Category.other: return 0xFF9B9B9B;
    }
  }
}

class Expense {
  final String id;
  final String title;
  final double amount;
  final Category category;
  final DateTime date;
  final String? note;

  Expense({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
    this.note,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'amount': amount,
    'category': category.index,
    'date': date.toIso8601String(),
    'note': note,
  };

  factory Expense.fromMap(Map<String, dynamic> map) => Expense(
    id: map['id'],
    title: map['title'],
    amount: map['amount'].toDouble(),
    category: Category.values[map['category']],
    date: DateTime.parse(map['date']),
    note: map['note'],
  );

  String toJson() => jsonEncode(toMap());
  factory Expense.fromJson(String source) => Expense.fromMap(jsonDecode(source));
}
